This is a beamer theme with the new Institute of Informatics (from UFRGS)
visual identity style. Enjoy!

